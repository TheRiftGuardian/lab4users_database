const express = require('express');
const mongoose = require('mongoose');
const userRouter = require('./routes/userRouter');

const app = express();
app.use(express.json());

mongoose
	.connect(
		'mongodb+srv://TheRiftGuardian:S6fdxxikdhRL29K@comp3123.okoru.mongodb.net/lab4users_database?authSource=admin&replicaSet=atlas-tn0e20-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true',
		{
			useNewUrlParser: true,
			useUnifiedTopology: true
		}
	)
	.then((success) => {
		console.log(`MongoDB connected ${success}`);
	})
	.catch((err) => {
		console.log(`Error while MongoDB connection ${err}`);
	});

app.use(userRouter);

app.listen(3000, () => {
	console.log('Server is running on port 3000');
});
